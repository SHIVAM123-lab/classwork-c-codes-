/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int arr[100];
int a,number,sum,flag,size,j,c;
    scanf("%d",&a);
    while(a-->0){
        scanf("%d",&number);
      // arr=ways(number);
      j=1;
      while(j<number){
        sum=0,flag=0,c=0;
        for(int i=j;i<number;i++){
            sum=sum+i;
            arr[c]=i;
            size=c;
            if(sum>number){
             break;   
            }
            if(sum==number){
                flag=1;
              
            }
            c++;
              if(flag==1){
             if(c>=2 && c<=10){
              for(int i=0;i<=size;i++){
                  printf("%d ",arr[i]);
              }
              printf("\n");
              flag=1;
               break;
             }else{
              c=0;
              sum=0;
              flag=0;
             }
          }
            
        
        }
          if(flag==1){
              break;
          }
      j++;
        
      }
    }

 
}
