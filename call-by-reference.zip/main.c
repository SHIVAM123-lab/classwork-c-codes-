/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
//SIR WORDS IN  STARTING -"IF YOU WANT TO RETURN TWO VALUES IN RECURSION 1.. TAKE ONE STATIC 
//2.. CALL BY REFRENCE//"
void recursion(int *c){
    *c=1234;
}
int main()
{//2..//
int count=0;
    recursion(&count);
    printf("%d",count);
    return 0;
}
