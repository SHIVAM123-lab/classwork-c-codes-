/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
int a=4,b=2;
Stack<Integer> s=new Stack<Integer>();

s.push(a);
s.push(b);

   int c=s.peek();
    s.pop();
int d=s.peek();
s.pop();
s.push(d+c);
System.out.println(s.peek());


	}
}

