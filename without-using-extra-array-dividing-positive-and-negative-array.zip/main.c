/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    //without using an extra array//
    int arr[]={10,-8,3,-6,5,4,3,-2};
int temp,count=0;
    for(int i=0;i<8-count;i++){
        if(arr[i]<0){
            count++;
           temp=arr[i];
            for(int j=i;j<7;j++){
                arr[j]=arr[j+1];
            }
            arr[7]=temp;
        }
    }
    for(int i=0;i<8;i++){
    
        printf("%d ",arr[i]);
    }
}
