/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
struct stack{
char arr[10];
int index[10];    
}s[6];
int i=-1;
    void push(char a){
      i++;
      s[i].arr[i]=a;
  
    }
    void pushInt(int a){
        s[i].index[i]=a;
    }
int empty(){
        if(i==-1){
            return 1;
        }else{
            return 0;
        }
    }
    void pop(){
        i--;
    }
    int top(){
        return s[i].arr[i];
    }
    int index(){
        return s[i].index[i];
    }
int main()
{ int j=0,temp;
   char *o="h[el(l)o(h[e[y]h]e]y";
   while(1){
       if(o[j]=='\0'){
       break;
   }
   if(o[j]=='('||o[j]=='['){
      push(o[j]);
      pushInt(j);
   }
   if(o[j]==')'||o[j]==']'){
      if(top()+1==o[j]||top()+2==o[j]){
         pop();
      }else
      {
          printf("%d",j);
          push(o[j]);
          printf("%d",j);
          pushInt(j);
       
      }
   }
       j++;
   }
if(empty()){
    printf("sequenced");
}   else{
    printf("not sequenced:= ");
    while(1){
if(empty()){
    break;
}
    printf("%d ",index());
    pop();
}
        
    }

}

