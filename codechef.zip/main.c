#include <stdio.h>

int main(void) {
int t,n,count,c,j,flag;
scanf("%d",&t);
while(t-->0){
    count=2;
    c=1;
   scanf("%d",&n);
   int arr[n],a[n];
   for(int i=0;i<n;i++){
       scanf("%d",&arr[i]);
   }
   while(c<n-1){
       j=0;
       while(j<n){
           flag=0;
    for(int i=0;i<n;i++){
       a[i]=arr[i];
   }       
           for(int i=0;i<c;i++){
               for(int i=j;i<n-1;i++){
                   int temp=arr[i];
                   arr[i]=arr[i+1];
                   arr[i+1]=temp;
               }
               j++;
           }
           if(c>1){
               j--;
           }
           for(int i=0;i<n-c;i++){
               if(arr[i]>arr[i+1]){
                  flag=1;
                  break;
               }
           }
           if(flag==0){
               count++;
           }
       }
       c++;
   }
   printf("%d\n",count);
   
}
    
}

