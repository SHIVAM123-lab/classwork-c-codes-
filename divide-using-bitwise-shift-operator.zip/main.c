#include <stdio.h>
#include<math.h>
int main()
{     //for(int i=0;i<n;i++)///complexicity;-o(n)
     //according to me;=
    //for(int i=0;i<n/2;i++)///complexicity:-o(n/2)
   //actual complexicity;=o(n)//
int n=12,z=3;
z=log2(3);
printf("%d\n",z);

n=n&n-1;

n=n>>z;
printf("%d",n);
}
