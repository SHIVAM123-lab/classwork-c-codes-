#include <stdio.h>

int main()
{
    int mid(int *a,int i,int j){
    static int k;
        if(a[j]==-1||a[j-1]==-1){
            k=i;
            return i-1;
            }
        i=i+1;
        j=j+2;
        int y=mid(a,i,j)-1;
       a[y]=a[y-1]+a[k];
       a[k]=a[y];
      
       printf("%d\n",a[k]);
        k++;
      return y;
    
    }
int arr[20],n,i=0,j=0;
scanf("%d",&n);
for(int q=0;q<n;q++){
    scanf("%d",&arr[q]);
}   
    arr[n]=-1;
    printf("%d",mid(arr,i,j));
    
}
            