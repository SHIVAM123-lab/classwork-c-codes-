//MERGE SORTING//
#include <stdio.h>
void merge(int * arr,int l,int r,int m){
    int y[r+1],i=l,j=m+1,count=0;
    while(i<=m && j<=r){
        if(arr[i]<arr[j]){
            y[count]=arr[i];
            i++;
            
        }else{
            y[count]=arr[j];
            j++;
        }
        printf("%d\n",y[count]);
         count++;
    }

    while(i<=m){
        y[count]=arr[i];
        i++;
        count++;
    }
    while(j<=r){
        y[count]=arr[j];
        j++;
        count++;
        
    }
    for(int q=l;q<count;q++){
    arr[q]=y[q];
    printf("%d ",arr[q]);
    }
    printf("\n");
}
void merge_sort(int *a,int l,int r){
if(l<r){
int m;
m=(l+r)/2;
merge_sort(a,l,m); 
merge_sort(a,m+1,r);   
merge(a,l,r,m);
    
}
}
int main()
{
int arr[]={10,80,30,90,40,50,70};
int l=0,r=6;
merge_sort(arr,l,r);
for(int i=0;i<=r;i++){
    printf("%d ",arr[i]);
}
}
