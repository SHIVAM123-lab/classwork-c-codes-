/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int arr[10],i=-1;
    void push(int a){
      i++;
      arr[i]=a;
  
    }
int empty(){
        if(i==-1){
            return 1;
        }else{
            return 0;
        }
    }
    void pop(){
        i--;
    }
    int top(){
        return arr[i];
    }
int main()
{
    //structures//
    //no classes //
    push(10);
    push(20);
    push(30);
    push(40);
    pop();
printf("%d",top());
}