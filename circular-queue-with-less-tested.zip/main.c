#include <stdio.h>
int l=-99,r=-99,m=0,flag=0;
int arr[5];
void enqueue(int a){

  if(m==0){
      l=r=0;
      m=1;
  }
  if(l>0){
      r=0;
      flag=1;
  }
if(r>=5||r==l && m==-1){
    printf("overflow");
exit(0);
}
  arr[r]=a;

    r++;
    m=-1;
}
int dequeue(){
  if(r==-99|| l==r && flag==0){
      printf("underflow");
 
      exit(0);
  }else{
      if(l==5){
       l=0;   
       flag=0;
      }
    l++;
    return arr[l-1];
}
}
int empty(){
    if(l==r){
        return 1;
    }else{
        return 0;
    }
}

int main()
{
 
    enqueue(3);
    enqueue(4);
    enqueue(5);
    enqueue(4);
        enqueue(5);
    printf("%d\n",dequeue());
    
    printf("%d\n",dequeue());
    enqueue(5);
     enqueue(90);
    printf("%d\n",dequeue());
    printf("%d\n",dequeue());
    printf("%d\n",dequeue());
    printf("%d\n",dequeue());
    
}
