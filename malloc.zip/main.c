/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
//doubt//
#include <stdio.h>
int* recursion(int b){
int *p=&b;
 printf("%p\n",p);
//int *p=malloc(4);
//*p=b;
 return p;
}
int main()
{
int a=90;
int *p= recursion(a);

 printf("%p",p);
printf("%d",*p);    
}
