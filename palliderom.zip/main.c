
#include <stdio.h>
#include<string.h>
//elle//
//
void pal(char *u){
    int i=0,flag=0,count=0,j;
    while(u[i]!=NULL){
        count++;
      i++;  
    }
    i=0;
    j=count-1;
    while(i<j){
    if(u[i]==u[j]){
        
    }  else{
        flag=1;
        break;
    }  
    i++;
    j--;
    }
    if(flag==0){
    printf("paliderom");
    }else{
        printf("not paliderom");

    }
}
int main()
{
    char *tr="ellocoderre";
    pal(tr);
    return 0;
}
