/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void swap(int *l,int *r){
int element = *l;
*l=*r;
*r=element;
}
int main()
{ int arr[]={4,8,7,-9,-8,-5,6};

int size = (int)sizeof(arr)/4;
int *left = arr;
int *right = arr+size-1;
while(left<right){
    if(*left>0){
        if(*right<0){
            swap(left,right);
            left++;
        }else{
            right=right-1;
        }
    }else{
        left++;
    }
}
int i=0;
while(i<size){
    printf("%d ",arr[i]);
    i++;
}

}
