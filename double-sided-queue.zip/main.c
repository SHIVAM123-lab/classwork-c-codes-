#include <stdio.h>
//std::queue<T> ;
int queue[8],i=0,j=0,z=7,m=7;
void enqueue(int a){
    if(i==8){
        printf("Array out of bound");
        exit(0);
    }
    queue[i]=a;
    i++;
}
void enqueue1(int a){
    if(z==-1){
        printf("Array2 out of bound");
        exit(0);
    }
    queue[z]=a;
    z--;
}
int dequeue(){
    
    return queue[j++];
}
int dequeue3(int a){
    
    return queue[a];
}

int dequeue1(){
    
    return queue[m--];
}
int isempty(){
    if(i==j){
        return 1;
        
    }
else{
    return 0;
}
    
}

int isempty1(){
    if(z==m){
        return 1;  
        }
else{
    return 0;
}
    
}
int main()
{
    enqueue(3);
    enqueue(4);
    enqueue(7);
    enqueue(5);
    enqueue(3);
while(!isempty())
{
    printf("%d",dequeue());
}
enqueue1(5);
enqueue1(8);
enqueue1(5);
enqueue1(1);
enqueue1(5);
while(!isempty1())
{
    printf("--%d",dequeue1());
}
printf("%d",queue[4]);
}