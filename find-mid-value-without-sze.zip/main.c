/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
int n;
scanf("%d",&n);
 int arr[n+1];
 for(int i=0;i<n;i++){
     scanf("%d",&arr[i]);
 }
 arr[n]=-1;
 //if i want to find mid//
 //arr[n/2]//
 //but what if i do not know size and i dont want to use any loop for it to determine size//
 //solution//
 int j=0;
 for(int i=0;i<n;i++){
  if( arr[j]==-1||arr[j-1]==-1)
  {
      printf("MID:-%d",arr[i-1]);
      
  }
   j=j+2;
   
 }

 
 
}

