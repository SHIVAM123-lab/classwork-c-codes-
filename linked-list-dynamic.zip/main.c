#include <stdio.h>
struct node *locp=NULL,*start,*p;
int count=1;
struct node {
    int data;
    struct node *link;
};
void add(int u){
    
    struct node *ptr=(struct node *)malloc(sizeof(struct node));
if(locp!=NULL){
 locp->link=ptr;
}
 ptr->data=u;
 ptr->link=NULL;
 locp=ptr;
 if(count==1){
 start=ptr;
 p=start;
 count=2;
 
}}
void print(){
    while(start!=NULL){
        printf("%d\n",start->data);
        
        start=start->link;
    }
}
void insert(int y,int position){
  struct node *ptr=(struct node *)malloc(sizeof(struct node));

  ptr->data=y;
  while(position>1){
     p=p->link;
    position--;  
  }
  ptr->link=p->link;
  p->link=ptr;
  p=start;
}
void delete(int s){
    struct node *u;
    while(s>1){
        p=p->link;
        
        s--;
    }
    u=p;
    u=u->link;
    u=u->link;
    p->link=u;
    
}
int main()
{
    add(2);
    add(4);
    add(22);
add(23);
add(90);
//deleteAtFirst()//
//deleteAtLast()//
delete(2);
  print();  
    
}
