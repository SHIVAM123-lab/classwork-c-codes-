
#include <stdio.h>
struct hash{
char s[5];
 int count;   
 struct hash *next;
}h[540];
int main()
{
char *str="hello how woh you are era is end";
int i=0,flag;
int sum=0;
char c[5],u=0;
while(str[i]!='\0'){
    if(str[i]!=' '){
        c[u]=str[i];
sum=sum+(int)str[i];
u++;
}else{
    flag=0;
    if(h[sum].s!=NULL){
   for(int j=0;j<u;j++){
    if(h[sum].s[j]==c[j]){
        
    }else{
        flag=1;
        break;
    }
   }    
    }else{
    for(int j=0;j<u;j++){
    h[sum].s[j]=c[j];
    }    
    }
    if(h[sum].next==NULL){
    if(flag==1){
        struct hash*ptr=(struct hash*)malloc (sizeof(struct hash));
    
            for(int j=0;j<u;j++){
        ptr->s[j]=c[j];
    }
    if(ptr->count>=1){
        ptr->count++;
    }else{
        ptr->count=1;
    }
    h[sum].next=ptr;
    
    }
        
    }else{
        
    }
    if(h[sum].count>=1){
      h[sum].count++; 
    }else{
    h[sum].count=1;
    }
    u=0;
    sum=0;
    
}
i++;
    
}  
for(int j=0;j<540;j++){
if(h[j].count==0){
    
}else{
    printf("%s %d\n",h[j].s,h[j].count);
}
}
    
}


