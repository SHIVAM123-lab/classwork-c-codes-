#include <stdio.h>
#include<stdlib.h>
struct node{
    struct node *left;
    int data;
    struct node *right;
};
int count=1;
struct node *head=NULL;
struct node *ptr=NULL;
void make_bst(struct node *h , int a){

//printf("%d--\n",a);
if(count==1){
    ptr=(struct node*)malloc(sizeof(struct node));
ptr->data=a;
    head=ptr;
    h=head;
    count=2;
}
if(h->data>a){
    if(h->left!=NULL){
    make_bst(h->left,a);    
    }else{
        ptr=(struct node*)malloc(sizeof(struct node));
ptr->data=a;
        h->left=ptr;
    
    }
}else{
    if(h->right!=NULL){
    make_bst(h->right,a);    
    }else{
        ptr=(struct node*)malloc(sizeof(struct node));
ptr->data=a;
        h->right=ptr;
    
    }
}
}
void traversalsmall(struct node *h,int c){
        if(h==NULL){
        
    }else{
       
        traversalsmall(h->left,c);
        traversalsmall(h->right,c);
        if(h->data<=c){
        printf("%d ",h->data);
            
        }
    }
}
void traversallarge(struct node *h,int c){
        if(h==NULL){
        
    }else{
       
        traversallarge(h->left,c);
        traversallarge(h->right,c);
         if(h->data>c){
        printf("%d ",h->data); 
            
        }
    }
}

int main()
{
 int arr[]={50,40,30,45,55,68};
 
 for(int i=0;i<7;i++){
make_bst(head ,arr[i]);
}
int b;
scanf("%d",&b);
 traversalsmall(head,b); 
 printf("\n");
 traversallarge(head,b);
 }
