void processString(char *a) 
{int count=2,j=0,size=sizeof(a);
  while(size>=2){
    int flag=0;
  for(int i=0;i<size;i++){
    if(a[i]==a[i+1]){
      while(count>0){
     for(j=i;j<size;j++){
      a[j]=a[j+1];
     }
        
        count--;
        size--;
      }
      flag=1;
      break;
    }
  }
    if(flag==0){
      break;
    }
    
  }
    printf("%s",a);
  
}
int main(){
    char o[]="axbbxr";
    processString(o);
}
