/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
int n;
scanf("%d",&n);
 int arr[n+1];
 for(int i=0;i<n;i++){
     scanf("%d",&arr[i]);
 }
 arr[n]=-1;
 //if i want to find mid//
 //arr[n/2]//
 //but what if i do not know size and i dont want to use any loop for it to determine size//
 //solution//
 int j=0;
 int k=0;
 int flag=0,even=0,odd=0;
 for(int i=0;i<9;i++){
 printf("%d ",arr[i]);
     
 }
 printf("\n");
 for(int i=0;i<n;i++){
  if( arr[j]==-1||arr[j-1]==-1)
  {
    flag=1;
      k=i-1;
      printf("h-%d p-%d index=%d\n",arr[j],arr[j-1],j);
   if( arr[j]==-1){
     even=1;
   }
     
    if(arr[j-1]==-1){
     odd=1;
   }   
  }
 
   //odd//
  if(flag==1){
   if(odd==1){
     k--;
   }
    
       arr[k]=arr[i]+arr[k];
       arr[i]=arr[k];
  if(even==1){
    k--;}
  
  }

   j=j+2;
   
 }
 for(int i=0;i<10;i++){
     if(arr[i]==-1){
         break;
     }else{
         printf("%d ",arr[i]);
     }
     
 }

 
 
}

