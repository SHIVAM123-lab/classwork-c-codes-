#include <stdio.h>
struct node{
int data;
struct node *next;
};
struct node *loc=NULL,*start,*start1;
int count=1;
void add(int a){
    struct node *ptr=(struct node*)malloc(sizeof(struct node));
if(loc!=NULL){
loc->next=ptr;
}
ptr->data=a;
ptr->next=NULL;
loc=ptr;
if(count==1){
    start=ptr;
    count=2;
}
loc=NULL;    
}
void add1(int a){
    struct node *ptr=(struct node*)malloc(sizeof(struct node));

if(loc!=NULL){
loc->next=ptr;
}
ptr->data=a;
ptr-next=NULL;
loc=ptr;
if(count==2){
    start1=ptr;
    count=3;
}
     
}
int main()
{
    add(2);
    add(34);
    add(5);
    add1(45);
    add1(2);
    add1(34);
}
