/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
 int i=0;
int *stack;


void push(int a){
  stack[i]=a;
  i++;  
}
int peek(){
    return stack[i-1];
}
int top(){
   return i-1; 
}
int pop(){
    i--;

   
    
}

int main()
{ int n;
    scanf("%d",&n);
    stack=malloc(n*4);
    push(10);
    push(20);
    push(30);
    push(40);
 int y=peek();   
printf("%d",y);
pop();
printf("%d",peek());
pop();
printf("%d",peek());

    
}
