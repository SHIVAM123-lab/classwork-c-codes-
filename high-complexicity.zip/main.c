
#include <stdio.h>

int main()
{
//question:zeroes upto all array zero//
int a,count=0,min=9999,flag=8;
scanf("%d",&a);
int *arr=malloc(a*sizeof(int));
if(arr==NULL){
    printf("error");
}
for(int i=0;i<a;i++){
    scanf("%d",&arr[i]);
}
while(flag!=0){
for(int i=0;i<a;i++){
    if(arr[i]==0){
        
    }else{
    if(min>arr[i]){
        min=arr[i];
    }
    }
}
for(int i=0;i<a;i++){
if(arr[i]==0){
    
}else{
    arr[i]=arr[i]-min;
}
printf("%d ",arr[i]);
}
printf("\n");
for(int i=0;i<a;i++){

  if(arr[i]==0){
      flag=0;
  } else{
      flag=1;
      break;
  }
    
}


}
}
