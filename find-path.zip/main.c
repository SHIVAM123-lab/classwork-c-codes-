/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *left;
    struct node *right;
};
int arr[20],count=0,c=19;
void enqueue(int a){
    arr[count]=a;
    count++;
}
void enqueue1(int a){
    arr[c]=a;
    c--;
}
int dequeue(){
  count--;
  return arr[count];   
}
int dequeue1(){
    c++; 
    return a[c];
}
struct node *h; 
void find_path(struct node *head){
if(head==NULL){
    
}
else
{
head->data;
enqueue(head->data);
enqueue1(h->data);
find_path(head->left);
find_path(head->right);
}
}
int main()
{
    int size,n;
    scanf("%d",&size);
    struct node *io;
    
    /*
while(size--){
ptr->data=n;
io->left=ptr;
io->right=ptr;
io=ptr;
}*/
struct node * head;
struct node *ptr=(struct node*)malloc(sizeof(struct node));
struct node *p=(struct node*)malloc(sizeof(struct node));
ptr->data=3;

p->data=48;
ptr->left=p;
struct node *p1=(struct node*)malloc(sizeof(struct node));
p1->data=90;
ptr->right=p1;
struct node *p1=(struct node*)malloc(sizeof(struct node));

p1->data=40;
p->left=p1;
struct node *p1=(struct node*)malloc(sizeof(struct node));
p1->data=82;
p->right=p1;
head=ptr;

find_path(head);

}
