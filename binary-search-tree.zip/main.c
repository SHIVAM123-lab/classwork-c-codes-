//bst(binary search tree)//
#include <stdio.h>
#include <stdlib.h>

 struct node *ptr=NULL;
 struct node *left1=NULL;
 struct node *right1=NULL;
 struct node *head=NULL,*h=NULL;
 int count=0,l=0,flag1=0,flag2=0,countarray=0;

struct node {
    struct node *left;
    struct node *right;
    int data;
};
 struct node  *arr[20];
 void push(struct node *a){
     if(countarray==0){
         arr[0]=NULL;
    countarray++;
     }
    arr[countarray]=a;
    countarray++;
 }
 struct node* pop(){
     
     countarray--;
return arr[countarray];
 }

void make_node(int a){
    h=head;
while(1){
    if(h==NULL){
        break;
    }
  if(h->data>a){
      if(h->left==NULL){

          flag1=1;
      
          break;
      }else{
     
          h=h->left;
      }
  } else{
      if(h->right==NULL){

      flag2=1;
      break;
      }else{
          h=h->right;
      }
  }
}
ptr=(struct node*)malloc(sizeof(struct node));//heap
if(l==0){
head=ptr;
h=head;
    l=1;
}
    ptr->data=a;
ptr->left=NULL;
ptr->right=NULL;
if(flag1==1){
    h->left=ptr;
    flag1=0;
}
if(flag2==1){
    h->right=ptr;
    flag2=0;
}
 
}
void traversal(struct node *y){
    if(y==NULL){
        
    }else{
        printf("%d\n",y->data);
       traversal(y->left); 
       traversal(y->right);
    }
 }
 void traversal_stack(struct node *h){
  
     if(h==NULL){
         
     }else{
            printf("%d\n",h->data);
     if(h->right!=NULL){
         push(h->right);
     }
     if(h->left==NULL){
         traversal_stack(pop());
     }else{
    h= h->left;
 traversal_stack(h);
     }}
 }
 struct node *prev=NULL;
 int c11=1,arr1[10],a[10],count1=0,count2=0;
 void levelordering(struct node *h){
   
   if(h==NULL){
      
   }else{
  if(c11==1){
     arr1[count1]=h->data;
    count1++;
  }else{
     a[count2]=h->data; 
     count2++;
    
 }      

 levelordering(h->left);
  if(head->data==h->data){
       c11=0;
   }
levelordering(h->right);
 }
 }
int main()
{
    int arr[]={15,12,6,13,19,18};
int size=6;
for(int i=0;i<size;i++){
make_node(arr[i]);    
}
//traversal(head);
//traversal_stack(head);
//printf("%d",(head->left)->data);
   levelordering(head);
   printf("level 1 -%d\n",arr1[0]);
     int g;
     for(int i=1;i<count1;i++){
         if(arr1[i]==0||a[i-1]==0){
             
         }else{
             g=i;
         }
     printf("level %d -- %d ",g+1,arr1[g]);
         printf("level %d -- %d ",g+1,a[g-1]);
     printf("\n");
         
     }
     for(int i=0;i<count1;i++){
         printf("%d",arr1[i]);
         }
         printf("\n");
     for(int i=0;i<count2;i++){
         printf("%d",a[i]);
         }
         
}




