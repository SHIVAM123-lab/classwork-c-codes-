
#include <stdio.h>
struct hash{
char s[5];
 int count;   
}h[540];
int main()
{
char *str="hello how are you are hello is hi hi hmm yo";
int i=0;
int sum=0;
char c[5],u=0,flag=0;
while((str[i]!='\0' || u!=0 )&& flag==0){
    if(str[i]!=' ' && str[i]!='\0'){
        c[u]=str[i];
sum=sum+(int)str[i];
u++;
}else{
    for(int j=0;j<u;j++){
    h[sum].s[j]=c[j];
    }
    if(h[sum].count>=1){
      h[sum].count++; 
    }else{
    h[sum].count=1;
    }
    u=0;
    sum=0;
    if(str[i]=='\0'){
        flag=1;
    }
    
}
i++;
    
}  
for(int j=0;j<540;j++){
if(h[j].count==0){
    
}else{
    printf("%s %d\n",h[j].s,h[j].count);
}
}
    
}


