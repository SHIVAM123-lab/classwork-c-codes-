/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
   int arr[4][4];
   for(int i=0;i<4;i++){
       for(int j=0;j<4;j++){
          scanf("%d",&arr[i][j]);
       }
   }
   int i=0,j=0;
int temp[3];
   while(1){
       arr[i][j];
       if(i==3){
        
           j--;
       }
       else{
       if(j==3){
           i++;
           
       }else{
j++;
}
           
       }
       printf("%d ",arr[i][j]);

     if(i==3 && j==0){
         break;
     }  
   }
}
