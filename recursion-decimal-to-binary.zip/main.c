#include <stdio.h>
#include<math.h>
int binary(int q){
    static int count=-1;
if(q==0){
    return 0;
}
count++;
return q%2*pow(10,count)+binary(q/2);    
}
int main()
{int n;
scanf("%d",&n);
printf("%d",binary(n));
}