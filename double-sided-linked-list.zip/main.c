#include <stdio.h>
struct node{
  struct node *back;
  struct node *forward;
  int data;  
};
struct node *loc=NULL,*start;
struct node *q;
    int count=1;
void add(int a){
    struct node *ptr=(struct node*)malloc(sizeof(struct node));
    ptr->data=a;
    ptr->back=loc;
    ptr->forward=NULL;
    if(loc!=NULL){
    loc->forward=ptr;
        
    }
    if(count==1){
    start=ptr;
    q=start;
        count=2;
    }
    loc=ptr;
    
}
 int empty(){
if(start==NULL){
        return 1;
    }
    return 0;
}
void traverseback(){
    printf("\n");
while(loc!=NULL){
printf("%d ",loc->data);
loc=loc->back;    
}
    
}
void traverseforward(){
    printf("\n");
while(!empty()){
    printf("%d ",start->data);
    start=start->forward;
}
start=q;
}
void insert(int a,int position){
    
    struct node *ptr=(struct node*)malloc(sizeof(struct node));
    while(position>0){
       start=start->forward;
        position--;
    }
    ptr->data=a;
    ptr->forward=start;
    ptr->back=start->back;
    (start->back)->forward=ptr;
    start->back=ptr;

    start=q;
}
int main()
{
add(2);
add(3);
add(4);
add(6);
add(1);
traverseforward();
traverseback();
insert(34,1);
traverseforward();
}
