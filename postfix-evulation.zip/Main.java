import java.util.*;

public class Main
{
	public static void main(String[] args) {
Stack <Integer> s=new Stack<Integer>();
	    String a="22+3/1+";
	    int b,c;
	    for(int i=0;i<a.length();i++){
	        if(!Character.isDigit(a.charAt(i))){
	       b=s.peek();
	            s.pop();
	        c=s.peek();
	        s.pop();
	        if(a.charAt(i)=='+'){
	        s.push(c+b);
	            
	        }
	        if(a.charAt(i)=='/'){
	            
	        s.push(c/b);
	        }
	         if(a.charAt(i)=='-'){
	            
	        s.push(c-b); 
	        }
	        
	            
	        }
	        else{
s.push(Integer.parseInt(Character.toString(a.charAt(i))));
	    }
	        
	    }
	    System.out.println(s.peek());
	}
}
