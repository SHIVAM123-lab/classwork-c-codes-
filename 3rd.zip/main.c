#include <stdio.h>

int main()
{
    int reverse(int a){
    static int n;
    int k;
    if(a<10){
        n=1;
        return a;
        
    }
     k=reverse(a/10);
n=n*10;
    return k+a%10*n;
    }
    int n;
    scanf("%d",&n);
    printf("%d",reverse(n));
    return 0;
}
