/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    
int arr[3];
for(int i=0;i<3;i++){
    scanf("%d",&arr[i]);
for(int j=0;j<i;j++){
    if(arr[j]==arr[i]){
        printf("enter a value again");
        i--;
        
    }
}
    
}
for(int i=0;i<3;i++){
    printf("%d\n",arr[i]);
    
}
    
}
