/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include<math.h>
//INPUT//1234123//
//OUTPUT//4344434//WITH ONLY ONE LOOP
int main()
{
    int arr[]={1,2,3,4,5,4};
    int size=6;
   int  mid=size/2;
    int j=size-1;
    for(int i=0;i<mid;i++){
        arr[i]=arr[i]+arr[j];
        arr[j]=arr[i];
        j--;
    }
    for(int i=0;i<size;i++){
        printf("%d ",arr[i]);
    }
}
