/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
//aaabbccde//
//sorted array  compress string a3b2c2// 
#include <stdio.h>
void compress(char *str){
 char s[sizeof(str)];
 int count=1;
 int size=sizeof(str);
 int j=0,i;
for(i=0;i<size+1;i++){
    if(str[i]==str[i+1]){
        count++;
    }else{
        if(count>=2){
        s[j]=str[i];
        s[j+1]=count+'0';
        j=j+2;
    }else{
      
        s[j]=str[i];
        j++;
    }
      count=1;  
    }
}
if(count==1){
    s[j]=str[i];
    
}else{
 s[j]=str[i];
 s[j+1]=count+'0';
}
printf("%s",s);
}
int main()
{
char *str="aaaabbbbef";
    compress(str);
 
   
}
