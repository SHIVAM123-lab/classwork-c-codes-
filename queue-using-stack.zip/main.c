/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int arr[20],i=-1,n=20;
    void push(int a){
      i++;
      arr[i]=a;
  
    }
int empty(){
        if(i==-1){
            return 1;
        }else{
            return 0;
        }
    }
    void pop(){
        i--;
    }
    int top(){
        return arr[i];
    }
    void pop1(){
        n++;
    }
    void copy(){
      
        while(!empty()){
            arr[n-1]=top();
            pop();
        n--;
            
        }
    
    }
    int empty1(){
        if(n==20){
            return 1;
        }
        else{
            return 0;
        }
    }
    int top1(){
        return arr[n];
    }
 int  deqeue(){
     copy();
     int a=top1();
     pop1();
     return a;
    } 
    void nqueue(int y){
        while(!empty1()){
     push(top1());
     pop1();
 }
  push(y); 
    }
int main()
{
    //structures//
    //no classes //
    nqueue(12);
    nqueue(40);
    nqueue(13);
    nqueue(67);
    
printf("%d\n",deqeue());
printf("%d\n",deqeue());

nqueue(40);




  
}

