//BST REVISION//
#include <stdio.h>
#include <stdlib.h>
struct node
{
  struct node *left;
  struct node *right;
  int data;
};
struct node *old, *head;
int count = 0, flag = 0;

void
make_node (int a, struct node *p)
{
  p->data = a;
  if (count == 0)
    {
      old = p;
      head = p;
      count++;
    }
  else
    {
      while (flag != 1)
	{
	  while (head->data > a)
	    {
	      if (head->left != NULL)
		{
		  head = head->left;
		}
	      else
		{
		  head->left = p;
		  flag = 1;
		  break;
		}

	    }
	  while (head->data < a)
	    {
	      if (head->right != NULL)
		{
		  head = head->right;
		}
	      else
		{
		  head->right = p;
		  flag = 1;
		  break;
		}

	    }
	}
      flag = 0;
      head = old;
    }

}
int max=0;
void
traversal (struct node *new,int c)
{
  if (new == NULL)
    {

    }
  else
    {
        c++;
     // printf ("%d\n", new->data);
      traversal (new->left,c);
      traversal (new->right,c);
      if(new->left==NULL && new ->right==NULL){
if(max<c){
    max=c;
}
        
      }

    }
}


//void
/*depth_count (struct node *h, int y)
{
  if (h == NULL)
    {

    }
  else
    {
      y++;
      depth_count (h->left, y);
      depth_count (h->right, y);
      if (max < y)
	{
	  max = y;
	  printf ("%d\n", y);

	}
      y = 0;
    }

}
void depth_count1(struct node *h){
    
}*/
int
main ()
{
  int arr[] = { 13, 20, 17, 24, 12, 11, 8, 10, 6, 4 };
  int i = 0;
  while (i < 10)
    {

      struct node *p = (struct node *) malloc (sizeof (struct node));
      make_node (arr[i], p);
      i++;
    }
    count=0;
  traversal (head,count);
  printf("%d--\n",max);
 //depth_count1 (head, 0);
}
