#include <stdio.h>
#include<stdlib.h>
struct node{
char *l;
struct node *next; 
};
struct hash{
    struct node *n; 
    int count;
}h[639];

int addhash(char *t){
int i=0,sum=0;
while(t[i]!='\0'){
    sum=sum+(int)t[i];
    i++;
}
return sum;
}
int count1=0;
struct node *u,*head;
void addhash1(char *t){
    int key=addhash(t);
   if(h[key].n==NULL){
    struct node *ptr=malloc(sizeof(struct node));
    
    ptr->l=t;
    if(u!=NULL){
u->next=ptr;
        
    }
    u=ptr;
h[key].n=ptr;
h[key].count=1;
if(count1==0){
    head=ptr;
    count1=1;
}
   }else{
    struct node *ptr=malloc(sizeof(struct node));
    ptr->l=t;
 if(h[key].count==1){
   struct node *y=h[key].n->next;
   h[key].n->next=ptr;
   ptr->next=y;
 }else{
     struct node *r=h[key].n;
       for(int i=0;i<h[key].count-1;i++){
           r=r->next;
       }
      struct node *y= r->next;
       r->next=ptr;
       ptr->next=y;
 }
 h[key].count++;

   }
}
int main()
{
   // char  *a="mumbai is the mumbia si eth ";

//int i=0,j=0;
addhash1("mumbai");
addhash1("hyu");
addhash1("is");
addhash1("the");
addhash1("mumbia");
addhash1("si");
addhash1("eth");
while(head!=NULL){
printf("%s\n",head->l);
head=head->next;
}

/*
while(a[i]!='\0'){
 
   if(a[i]==' '){
       
       printf("%s\n",d);
       addhash1(d);
       
       j=0;
      
   }else{
     d[j]=a[i];
     j++;
   }
   i++; 
}*/

}

