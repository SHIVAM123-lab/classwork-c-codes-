#include <stdio.h>
#include<math.h>
 int count=-1,c=0,temp,temp1;
int binary(int q){
if(q==0){
    return 0;
}
count++;
return q%2*pow(10,count)+binary(q/2);    
}
int hexdec(int a){
    if(a==0){
      return 0;  
    }
        temp=pow(10,c);
    temp1=binary(a%10);
    c=c+count+1;
    count=-1;
    return temp1*temp+hexdec(a/10);
    
    
}
int main()
{int n;
scanf("%d",&n);
printf("%d",hexdec(n));
}
