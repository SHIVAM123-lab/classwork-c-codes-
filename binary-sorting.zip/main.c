/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int j,i=0,temp,n;
    //COMPLEXICITY O(N)//
    scanf("%d",&n);
    int arr[n];
    for(int i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
j=n-1;
while(i<j){

if(arr[i]==0 && arr[j]==1){
 temp=arr[i];
 arr[i]=arr[j];
 arr[j]=temp;
j--;
 i++;
}    
if(arr[j]!=1){
j--;
}
if(arr[i]!=0){
i++;
    
}

}

for(int i=0;i<n;i++){
    printf("%d ",arr[i]);
}

    return 0;
}
