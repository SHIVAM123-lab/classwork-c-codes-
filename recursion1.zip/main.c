#include <stdio.h>
int main()
{//recursion//
  int factorial(int a){
    if(a==1){
  return 1;
    }
return a*factorial(a-1);

  }
  int n,mul=1;
  scanf("%d",&n);
  printf("%d",factorial(n));

    return 0;
}