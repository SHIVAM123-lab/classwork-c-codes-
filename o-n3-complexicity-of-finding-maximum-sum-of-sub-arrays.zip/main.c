/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{int arr[]={1,3,1,7};
int n=4,count,max,sum=0;
int a[10];
//3 nested loop o(n3)//
for(int i=0;i<n;i++){
    count=i+1;
    while(count<=n){
        max=-10;
    for(int j=i;j<count;j++){

    if(max<arr[j]){
    max=arr[j];
    }
        
    }
     
sum=sum+max;
    count++;
    }
    
}
printf("%d",sum);
}
