

#include <stdio.h>
int count=0;
struct node{
    int info;
    struct node *link;
};
struct node q[5],*trav=&q[0];
void push(int a){
q[count].info=a;
q[count].link=&q[count+1];
count++;

}
int pip(){
int temp= trav->info;
trav=trav->link;
return temp;
}
int main()
{
    /*struct node *j=(struct node*) malloc(sizeof(struct node));
    struct node *k=(struct node*)malloc(sizeof(struct node));
    struct node *l=(struct node*)malloc(sizeof(struct node));
    struct node *trav;
    trav=&j;
j.info=10;
j.link=&k;
k.info=20;
k.link=&l;
l.info=90;
l.link=0;*/
push(1);
push(2);
push(3);
push(2);
push(3);
 printf("%d\n",pip());
 
 printf("%d\n",pip());
 printf("%d\n",pip()); 
 printf("%d\n",pip());
 
 printf("%d\n",pip());

}
