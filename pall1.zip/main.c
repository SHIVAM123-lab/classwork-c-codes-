#include <stdio.h>
#include<string.h>
//elle//
void pal(char *u){
    int i=0,flag=0,count=0,j,c,cup,c1,com,v;
    while(u[i]!='\0'){
        count++;
      i++;  
    }
    i=0;
    j=count-1;
    while(i<j){
        v=0;
         c=i;
    cup=j;
    while(c<cup){
    if(u[c]==u[cup] ){
        if(cup-c==1){
            flag=1;
            
        }
         if(v==0){
             com=cup;
             v=1;
         }   
        c++;
    }
    cup--;
    }
    if(flag==1){ 
        for(int y=i;y<=com;y++){
           printf("%c",u[y]); 
        }
        printf("\n");
        flag=0;
    }
    
    i++;
    }
 
}
int main()
{
    char *tr="hellocoderredocobyepip";
    pal(tr);
    return 0;
}

