/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
//immutable strings//
int main(){
char *o=NULL;
char *u="hello";
o=u;
for(int i=0;i<100;i++){
if(u[i]=='\0'){break;}

printf("%c",u[i]);
 }   return 0;
}
