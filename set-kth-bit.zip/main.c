#include <stdio.h>

int main()
{
    int k;
    int n;
    scanf("%d",&k);
    scanf("%d",&n);
    k=pow(2,k-1);
    printf("%d",n|k);
}
