#include <stdio.h>
#include<math.h>
//INPUT//1234123//
//OUTPUT//4444444//WITH ONLY ONE LOOP
int y=0,count=0;
void add(int *arr,int i,int j){
  
    if(arr[j-1]==-90 ){
 y=i;    
 count=1;
    }else if(arr[j]==-90){
        y=i;
    }
    else{
        add(arr,i+1,j+2);
    
    if(count==1){
        count=2;
    }else{
        arr[i]=arr[i]+arr[y];
        arr[y]=arr[i];
        y++;
    }
        
    }
    }

int main()
{
    int arr[]={4,10,11,12,14,-90};
int i=0,j=0;
add(arr,i,j);
  while(arr[j]!=-90){
      printf("%d ",arr[j]);
      j++;
  }  
}


