/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	String g="saachinvermahello";
	StringBuffer sb=new StringBuffer(g);
char vowels[]={'a','e','i','o','u'};

		System.out.println(sb.length());
for(int i=0;i<sb.length();i++){
   for(int j=0;j<5;j++){
    if(sb.charAt(i)==vowels[j]){
        sb.deleteCharAt(i);
        i--;
       
        break;
    }
}
	}	
		System.out.println(sb);
}
    
}
