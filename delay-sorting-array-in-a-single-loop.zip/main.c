/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{/*
    int arr[]={1,2,3,4,5};
    int l=0,r=4;
    int m=(l+r)/2;//2
    int le[m-l+1],ri[r-m];
    for(int i=0;i<=m;i++){
        le[i]=arr[i];
    }
    for(int i=0;i<=r-m;i++){
        ri[i]=arr[i+m];
    }
    printf("%d",le[2]);
*/
/*int a[]={1,0,2,90}
    int arr[]={3,6,3,8};
    int arr1[8];
    //assume size of a=size of arr;
    //array sorted//
//complexixity o(n)//i can use only one for loop
    for(int i=0;i<4;i++){
     if(a[i]<arr[i])   
    }
*/
int arr[]={1,12,2,13,5};
int size=5;
int mid=size/2;
int j=4;
while(i<j){
    if(arr[i]> arr[j]){
        
    }
    if(arr[i]<arr[j]){
        i++;
    }
}
}
