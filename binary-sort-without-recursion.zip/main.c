#include <stdio.h>
//linear search//complexixity:o(n)//
int main()
{
int arr[]={1,2,3,3,7,65};
int a=6,mid=a/2,find=65;
while(mid>=0 && mid<a){
if(arr[mid]==find){
        printf("%d\n",mid);
        break;
    
}
if(arr[mid]<find){
mid++;
}else {
   mid--;
    }
    
}
    
}
/*
for(int i=0;i<6;i++){
    if(arr[i]==7){
        printf("%d\n",i+1);
    }
}
*/
    

